// fantasia, aventura, drama

// Para todos os garotos que ja amei, 12, romence, 
// Enola holmes,12 , aventura 
// Milagres do paraiso, 10, drama, 
// Jogos vorazes1 e 2 , 14, ficcao cientifica, drama 
// legalmente loira 1 e 2, livre, comedia,
// miss simpatia, livre, comedia, suspense, romance
// Jumanji bem vindo a selva, 12, fantasia, aventura

let campoIdade;
let campoFantasia;
let campoAventura;

function setup() { 
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
  campoDrama = createCheckbox("Gosta de drama?");
  campoRomance = createCheckbox("Gosta de romance?");      campoSuspence = createCheckbox("Gosta de fantasia?");
 campoComedia = createCheckbox("Gosta de comedia?");
  campoFicaocientifica = createCheckbox("Gosta de ficcao cientifica?");
  
function draw() {
  background("purple");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "Para todos os garotos que ja amei";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "Enola homes";          
        } else{
         return "milagre do paraiso";
        }
      } else {
        if (gostaDeFantasia) {
          return "Jogos vorazes 1 e 2";
        } else {
          return "Legalmente loira 1 e 2";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "Miss simpatia";
    } else {
      return "Jumanji bem vindo a selva";
    }
  }
}